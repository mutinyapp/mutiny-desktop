import { MakerAppX } from "@electron-forge/maker-appx";
import { MakerDeb } from "@electron-forge/maker-deb";
import { MakerFlatpak } from "@electron-forge/maker-flatpak";
import { MakerFlatpakOptionsConfig } from "@electron-forge/maker-flatpak/dist/Config";
import { MakerSquirrel } from "@electron-forge/maker-squirrel";
import { MakerZIP } from "@electron-forge/maker-zip";
import { FusesPlugin } from "@electron-forge/plugin-fuses";
import { VitePlugin } from "@electron-forge/plugin-vite";
import { PublisherGithub } from "@electron-forge/publisher-github";
import type { ForgeConfig } from "@electron-forge/shared-types";
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { FuseV1Options, FuseVersion } from "@electron/fuses";

const DEEPFILTERNET3_DIST = join(
  __dirname,
  "node_modules",
  "deepfilternet3-noise-filter",
  "dist",
);

// import { globSync } from "node:fs";

const STRINGS = {
  author: "Mutiny",
  name: "Mutiny",
  execName: "mutiny-desktop",
  description: "Mutiny desktop chat client.",
};

const ASSET_DIR = "assets/desktop";
const PACKAGE_VERSION = JSON.parse(
  readFileSync(join(__dirname, "package.json"), "utf8"),
).version as string;

/**
 * Build targets for the desktop app
 */
const makers: ForgeConfig["makers"] = [
  new MakerSquirrel({
    name: STRINGS.name,
    authors: STRINGS.author,
    iconUrl: `https://raw.githubusercontent.com/mutinyapp/mutiny-desktop/v${PACKAGE_VERSION}/assets/desktop/icon.ico`,
    // todo: loadingGif
    setupIcon: `${ASSET_DIR}/icon.ico`,
    description: STRINGS.description,
    exe: `${STRINGS.execName}.exe`,
    setupExe: "Mutiny-Setup.exe",
    copyright: "Copyright (C) 2025 Mutiny",
  }),
  new MakerZIP({}),
];

// skip these makers in CI/CD
if (!process.env.PLATFORM) {
  makers.push(
    // must be manually built (freezes CI process)
    // not much use in being published anyhow
    new MakerAppX({
      certPass: "",
      packageExecutable: `app\\${STRINGS.execName}.exe`,
      publisher: "CN=B040CC7E-0016-4AF5-957F-F8977A6CFA3B",
    }),
    // flatpak publishing should occur through flathub repos.
    // this is just for testing purposes
    new MakerFlatpak({
      options: {
        id: "gg.mutinyapp.mutiny-desktop",
        description: STRINGS.description,
        productName: STRINGS.name,
        productDescription: STRINGS.description,
        runtimeVersion: "21.08",
        icon: `${ASSET_DIR}/icon.png`,
        categories: ["Network"],
        modules: [
          // use the latest zypak -- Electron sandboxing for Flatpak
          {
            name: "zypak",
            sources: [
              {
                type: "git",
                url: "https://github.com/refi64/zypak",
                tag: "v2025.09",
              },
            ],
          },
        ],
        finishArgs: [
          // default arguments found by running
          // DEBUG=electron-installer-flatpak* pnpm make
          "--socket=x11",
          "--share=ipc",
          "--device=dri",
          "--socket=pulseaudio",
          "--filesystem=home",
          "--env=TMPDIR=/var/tmp",
          "--share=network",
          "--talk-name=org.freedesktop.Notifications",
          // add Unity talk name for badges
          "--talk-name=com.canonical.Unity",
        ],
        // files: [
        //   // is this necessary?
        //   // https://stackoverflow.com/q/79745700
        //   ...[16, 32, 64, 128, 256, 512].map(
        //     (size) =>
        //       [
        //         `assets/desktop/hicolor/${size}x${size}.png`,
        //         `/app/share/icons/hicolor/${size}x${size}/apps/gg.mutinyapp.mutiny-desktop.png`,
        //       ] as [string, string],
        //   ),
        //   [
        //     `assets/desktop/icon.svg`,
        //     `/app/share/icons/hicolor/scalable/apps/gg.mutinyapp.mutiny-desktop.svg`,
        //   ] as [string, string],
        // ],
        files: [],
      } as MakerFlatpakOptionsConfig,
      /* as Omit<
        MakerFlatpakOptionsConfig,
        "files"
      > */
    }),
    // testing purposes
    new MakerDeb({
      options: {
        productName: STRINGS.name,
        productDescription: STRINGS.description,
        categories: ["Network"],
        icon: `${ASSET_DIR}/icon.png`,
      },
    }),
  );
}

const config: ForgeConfig = {
  packagerConfig: {
    asar: true,
    name: STRINGS.name,
    executableName: STRINGS.execName,
    appBundleId: "com.electron.mutiny",
    helperBundleId: "com.electron.mutiny.helper",
    icon: `${ASSET_DIR}/icon`,
    extraResource: [
      // Bundle DeepFilterNet3 noise suppression assets for offline use.
      // The web client can reference these locally when running in desktop mode.
      DEEPFILTERNET3_DIST,
    ],
    darwinDarkModeSupport: true,
    extendInfo: {
      NSMicrophoneUsageDescription:
        "Mutiny needs microphone access for voice chat.",
      NSCameraUsageDescription:
        "Mutiny needs camera access for video calls.",
      NSScreenCaptureUsageDescription:
        "Mutiny needs screen access for screen sharing.",
      NSAudioCaptureUsageDescription:
        "Mutiny needs system audio access for screen sharing.",
      CFBundleURLTypes: [
        {
          CFBundleURLName: "Mutiny Protocol",
          CFBundleURLSchemes: ["mutiny"],
        },
      ],
    },
  },
  hooks: {
    postPackage: async (_config, options) => {
      if (options.platform !== "darwin") return;

      // Signing is intentionally explicit. A macOS package without a selected mode
      // is neither a local-test build nor a releasable artifact.
      if (options.outputPaths.length !== 1) {
        throw new Error(
          `macOS signing requires exactly one Forge outputPath; received ${options.outputPaths.length}`,
        );
      }
      const appPath = resolve(options.outputPaths[0], `${STRINGS.name}.app`);
      execFileSync(
        process.execPath,
        [join(__dirname, "scripts", "macos-sign.mjs"), appPath],
        { stdio: "inherit" },
      );
    },
  },
  rebuildConfig: {},
  makers,
  plugins: [
    new VitePlugin({
      // `build` can specify multiple entry builds, which can be Main process, Preload scripts, Worker process, etc.
      // If you are familiar with Vite configuration, it will look really familiar.
      build: [
        {
          // `entry` is just an alias for `build.lib.entry` in the corresponding file of `config`.
          entry: "src/main.ts",
          config: "vite.main.config.ts",
          target: "main",
        },
        {
          entry: "src/preload.ts",
          config: "vite.preload.config.ts",
          target: "preload",
        },
        {
          // The fallback screen picker gets a separate, narrow IPC bridge.
          entry: "src/pickerPreload.ts",
          config: "vite.preload.config.ts",
          target: "preload",
        },
      ],
      renderer: [],
    }),
    // Fuses are used to enable/disable various Electron functionality
    // at package time, before code signing the application
    new FusesPlugin({
      version: FuseVersion.V1,
      [FuseV1Options.RunAsNode]: false,
      [FuseV1Options.EnableCookieEncryption]: true,
      [FuseV1Options.EnableNodeOptionsEnvironmentVariable]: false,
      [FuseV1Options.EnableNodeCliInspectArguments]: false,
      [FuseV1Options.EnableEmbeddedAsarIntegrityValidation]: true,
      [FuseV1Options.OnlyLoadAppFromAsar]: true,
    }),
  ],
  publishers: [
    new PublisherGithub({
      repository: {
        owner: "mutinyapp",
        name: "mutiny-desktop",
      },
    }),
  ],
};

export default config;
